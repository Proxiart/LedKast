#define TWITCH_OAUTH_TOKEN ""
#define SSID ""
#define PASS ""