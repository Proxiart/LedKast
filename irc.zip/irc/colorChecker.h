void colorChecker(String initial) {
  String squareNumber; //data String
  String kleur;
  String skipap;

  int ind1; // , locations
  int ind2;
  int squareNumberInt;
  int squareFinal;
  int squareFirst;

  //expect a string like 90,low,15.6,125*
  //or 130,hi,7.2,389*
  initial.remove(0, 7);
  Serial.println(initial);

  ind1 = initial.indexOf(' ');  //finds location of first ,
  squareNumber = initial.substring(0, ind1);   //captures first data String
  ind2 = initial.indexOf(',', ind1 + 1 ); //finds location of second ,
  kleur = initial.substring(ind1 + 1, ind2); //captures second data String

  Serial.print("squareNumber = ");
  Serial.println(squareNumber);
  Serial.print("kleur = ");
  Serial.println(kleur);


  //---- String to int---
  squareNumberInt = squareNumber.toInt();   //captures first data String
  int squareToLed = map(squareNumberInt, 1, 25, 0, 288);
  Serial.print("squaretoled = ");
  Serial.println(squareToLed);

  for (int i = squareToLed; i <= squareToLed + 11 ; i++) {
    Serial.print("i = ");
    Serial.println(i);
    if (kleur == "rood") {
      leds[i] = CRGB::Red;
      FastLED.show();
    }
    else if (kleur == "groen") {
      leds[i] = CRGB::Green;
      FastLED.show();
    }
    else if (kleur == "blauw") {
      leds[i] = CRGB::Blue;
      FastLED.show();
    }
    else if (kleur == "magenta") {
      leds[i] = CRGB::Magenta;
      FastLED.show();
    }
    else if (kleur == "wit") {
      leds[i] = CRGB::White;
      FastLED.show();
    }
    else if (kleur == "proxiart") {
      leds[i] = CRGB::LightBlue;
      FastLED.show();
    }
    else if (kleur == "guitarblaster3") {
      leds[i] = CRGB::Purple;
      FastLED.show();
    }
    else if (kleur == "speederxxl") {
      leds[i] = CRGB::LimeGreen;
      FastLED.show();
    }
    else if (kleur == "") {
      leds[i] = CRGB::Yellow;
      FastLED.show();
    }
  }





  Serial.print("squareToLed = ");
  Serial.println(squareToLed);

}

//  leds[squareNumberInt] = CRGB(redInt, greenInt, blueInt);
//  FastLED.show();
