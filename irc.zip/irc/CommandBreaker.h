//zoomkat 11-12-13 String capture and parsing
//from serial port input (via serial monitor)
//and print result out serial port
//copy test strings and use ctrl/v to paste in
//serial monitor if desired
// * is used as the data string delimiter
// , is used to delimit individual data

String squareNumber; //data String
String red;
String blue;
String green;

int ind1; // , locations
int ind2;
int ind3;
int ind4;
int squareNumberInt;
int redInt;
int blueInt;
int greenInt;

void CommandBreaker(String initial) {
  //expect a string like 90,low,15.6,125*
  //or 130,hi,7.2,389*
  initial.remove(0, 5);
  Serial.println(initial);

  ind1 = initial.indexOf(' ');  //finds location of first ,
  squareNumber = initial.substring(0, ind1);   //captures first data String
  ind2 = initial.indexOf(',', ind1 + 1 ); //finds location of second ,
  red = initial.substring(ind1 + 1, ind2); //captures second data String
  ind3 = initial.indexOf(',', ind2 + 1 );
  green = initial.substring(ind2 + 1, ind3);
  ind4 = initial.indexOf(',', ind3 + 1 );
  blue = initial.substring(ind3 + 1); //captures remain part of data after last ,

  Serial.print("squareNumber = ");
  Serial.println(squareNumber);
  Serial.print("red = ");
  Serial.println(red);
  Serial.print("green = ");
  Serial.println(green);
  Serial.print("blue = ");
  Serial.println(blue);
  Serial.println();
  Serial.println();

//---- String to int---
  squareNumberInt = squareNumber.toInt();   //captures first data String
  redInt = red.toInt(); //captures second data String
  blueInt = blue.toInt();
  greenInt = green.toInt();

  Serial.print("squareNumberInt = ");
  Serial.println(squareNumberInt);
  Serial.print("redInt = ");
  Serial.println(redInt);
  Serial.print("greenInt = ");
  Serial.println(greenInt);
  Serial.print("blueInt = ");
  Serial.println(blueInt);
  Serial.println();
}

void clearString(){
  squareNumber = "";
  red = "";
  green = "";
  blue = "";
}
